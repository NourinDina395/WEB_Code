// ---------------- CPU Scheduler + Banker's Algorithm (Corrected) ----------------

// DOM refs
const pidField = document.getElementById("pid");
const arrivalFieldInput = document.getElementById("arrival");
const burstField = document.getElementById("burst");
const priorityFieldInput = document.getElementById("priority");
const periodFieldInput = document.getElementById("period");

const addProcessBtn = document.getElementById("addProcessBtn");
const algorithmBox = document.getElementById("algorithm");
const quantumField = document.getElementById("quantum");
const runSchedulerBtn = document.getElementById("runSchedulerBtn");
const clearSchedulerBtn = document.getElementById("clearSchedulerBtn");
const cpuTable = document.getElementById("cpuTable").querySelector("tbody");
const ganttPanel = document.getElementById("ganttPanel");

const arrivalField = document.getElementById("arrivalField");
const priorityField = document.getElementById("priorityField");
const periodField = document.getElementById("periodField");

// mode toggle
const modeSelect = document.getElementById("modeSelect");
const cpuSection = document.getElementById("cpuSection");
const bankerSection = document.getElementById("bankerSection");

modeSelect.addEventListener("change", () => {
    if (modeSelect.value === "cpu") {
        cpuSection.style.display = "block";
        bankerSection.style.display = "none";
    } else {
        cpuSection.style.display = "none";
        bankerSection.style.display = "block";
    }
});
bankerSection.style.display = "none";

// processes stores raw task definitions (not individual periodic job instances)
let processes = []; // each: { pid, arrival, burst, priority, period, remaining }

// Globals for job/segment extraction
let lastSegmentsGlobal = null;
let lastGeneratedJobsGlobal = null;

// toggle visible fields based on algorithm
function handleAlgorithmFields() {
    const alg = algorithmBox.value;
    quantumField.disabled = alg !== "Round Robin";

    if (alg === "RMS" || alg === "EDF") {
        arrivalField.style.display = "inline-block";
        priorityField.style.display = "none";
        periodField.style.display = "inline-block";
    } else if (alg === "Priority") {
        arrivalField.style.display = "inline-block";
        priorityField.style.display = "inline-block";
        periodField.style.display = "none";
    } else {
        arrivalField.style.display = "inline-block";
        priorityField.style.display = "inline-block";
        periodField.style.display = "none";
    }
}
algorithmBox.addEventListener("change", () => {
    handleAlgorithmFields();
    // clear Gantt when changing algorithm to avoid stale visuals
    ganttPanel.innerHTML = "";
});
handleAlgorithmFields(); // init

addProcessBtn.addEventListener("click", () => {
    const pid = pidField.value.trim();
    if (!pid) return alert("Enter PID");
    const arrival = parseInt(arrivalFieldInput.value) || 0;
    const burst = parseInt(burstField.value);
    if (!burst || burst <= 0) return alert("Enter burst time > 0");
    const priority = parseInt(priorityFieldInput.value) || 0;
    const period = parseInt(periodFieldInput.value) || 0;

    const alg = algorithmBox.value;
    if ((alg === "RMS" || alg === "EDF") && (!period || period <= 0)) {
        return alert("For RMS/EDF you must enter a positive Period.");
    }

    // add task
    if (alg === "RMS" || alg === "EDF") {
        processes.push({ pid, arrival, burst, period, remaining: burst });
    } else {
        processes.push({ pid, arrival, burst, priority, remaining: burst });
    }

    updateTable();
    // clear simple fields
    pidField.value = "";
    // keep arrival/burst/period to allow adding similar tasks quickly
});

clearSchedulerBtn.addEventListener("click", () => {
    processes = [];
    cpuTable.innerHTML = "";
    ganttPanel.innerHTML = "";
    lastSegmentsGlobal = null;
    lastGeneratedJobsGlobal = null;
});

// update table shows current tasks (not job instances)
function updateTable() {
    cpuTable.innerHTML = "";
    const alg = algorithmBox.value;

    processes.forEach(p => {
        const tr = document.createElement("tr");
        const periodCell = ('period' in p) ? p.period : '-';
        const priorityCell = ('priority' in p) ? p.priority : '-';
        tr.innerHTML = `<td>${p.pid}</td><td>${p.arrival}</td><td>${p.burst}</td><td>${periodCell}</td><td>-</td><td>-</td><td>-</td><td>-</td><td>${priorityCell}</td>`;
        cpuTable.appendChild(tr);
    });
}

// RUN Scheduler button handling
runSchedulerBtn.addEventListener("click", () => {
    if (!processes.length) return alert("Add processes first");
    // reset globals for new run
    lastGeneratedJobsGlobal = null;
    lastSegmentsGlobal = null;
    const alg = algorithmBox.value;
    let segments = [];

    // For RMS/EDF we build job instances; for other algorithms we reuse previous implementations
    switch (alg) {
        case "FCFS":
            segments = scheduleFCFS(processes.map(p => ({ ...p })));
            break;
        case "SJF":
            segments = scheduleSJF(processes.map(p => ({ ...p })));
            break;
        case "SRTF":
            segments = scheduleSRTF(processes.map(p => ({ ...p })));
            break;
        case "Round Robin":
            let q = parseInt(quantumField.value);
            if (isNaN(q) || q <= 0) return alert("Quantum > 0");
            segments = scheduleRR(processes.map(p => ({ ...p })), q);
            break;
        case "Priority":
            segments = schedulePriority(processes.map(p => ({ ...p })));
            break;
        case "RMS":
            const rmsResult = scheduleRMS(processes.map(p => ({ ...p })));
            segments = rmsResult.segments;
            // store generated jobs (scheduleRMS already sets lastGeneratedJobsGlobal)
            updateJobTable(lastGeneratedJobsGlobal || rmsResult.jobs);
            break;
        case "EDF":
            const edfResult = scheduleEDF(processes.map(p => ({ ...p })));
            segments = edfResult.segments;
            updateJobTable(lastGeneratedJobsGlobal || edfResult.jobs);
            break;
        default:
            alert("Unknown algorithm");
            return;
    }

    if (alg !== "RMS" && alg !== "EDF") {
        // For classic algorithms, produce per-process summary (existing behavior)
        updateCPUTable(segments);
    }
    drawGantt(segments);
});

// ---------------- Existing scheduling algorithms (unchanged except small adapt) ----------------
function scheduleFCFS(list) {
    let listCopy = list.slice().sort((a, b) => a.arrival - b.arrival);
    let segs = [], time = 0;
    for (let p of listCopy) {
        if (time < p.arrival) time = p.arrival;
        segs.push({ pid: p.pid, start: time, finish: time + p.burst });
        time += p.burst;
    }
    return segs;
}

function scheduleSJF(list) {
    let listCopy = list.slice().sort((a, b) => a.arrival - b.arrival);
    let segs = [], time = 0;
    let rem = [...listCopy];
    while (rem.length) {
        let ready = rem.filter(p => p.arrival <= time);
        if (!ready.length) {
            time = Math.min(...rem.map(p => p.arrival));
            continue;
        }
        let p = ready.reduce((a, b) => a.burst < b.burst ? a : b);
        segs.push({ pid: p.pid, start: time, finish: time + p.burst });
        time += p.burst;
        rem = rem.filter(x => x !== p);
    }
    return segs;
}

function scheduleSRTF(list) {
    let segs = [], time = 0, i = 0;
    list.sort((a, b) => a.arrival - b.arrival);
    let pq = [];
    // copy remaining
    list = list.map(p => ({ ...p, remaining: p.burst }));
    while (i < list.length || pq.length) {
        while (i < list.length && list[i].arrival <= time) pq.push({ ...list[i++] });
        if (!pq.length) {
            if (i < list.length) time = list[i].arrival;
            continue;
        }
        pq.sort((a, b) => a.remaining - b.remaining);
        let cur = pq.shift();
        segs.push({ pid: cur.pid, start: time, finish: time + 1 });
        cur.remaining--;
        time++;
        while (i < list.length && list[i].arrival <= time) pq.push({ ...list[i++] });
        if (cur.remaining > 0) pq.push(cur);
    }
    return mergeSegments(segs);
}

function scheduleRR(list, quantum) {
    let segs = [], qlist = [], i = 0, time = 0;
    list.sort((a, b) => a.arrival - b.arrival);
    // copy remaining
    list = list.map(p => ({ ...p, remaining: p.burst }));
    while (i < list.length || qlist.length) {
        while (i < list.length && list[i].arrival <= time) qlist.push(list[i++]);
        if (!qlist.length) {
            if (i < list.length) time = list[i].arrival;
            continue;
        }
        let p = qlist.shift();
        let exec = Math.min(p.remaining, quantum);
        segs.push({ pid: p.pid, start: time, finish: time + exec });
        p.remaining -= exec;
        time += exec;
        while (i < list.length && list[i].arrival <= time) qlist.push(list[i++]);
        if (p.remaining > 0) qlist.push(p);
    }
    return mergeSegments(segs);
}

function schedulePriority(list) {
    list.sort((a, b) => a.arrival - b.arrival);
    let segs = [], time = 0;
    let rem = [...list];
    while (rem.length) {
        let ready = rem.filter(p => p.arrival <= time);
        if (!ready.length) {
            time = Math.min(...rem.map(p => p.arrival));
            continue;
        }
        let p = ready.reduce((a, b) => a.priority < b.priority ? a : b);
        segs.push({ pid: p.pid, start: time, finish: time + p.burst });
        time += p.burst;
        rem = rem.filter(x => x !== p);
    }
    return segs;
}

function mergeSegments(segs) {
    let out = []; if (!segs.length) return out;
    // ensure segments are sorted by start time
    segs.sort((a, b) => a.start - b.start || a.finish - b.finish);
    let cur = { ...segs[0] };
    for (let i = 1; i < segs.length; i++) {
        let s = segs[i];
        if (s.pid === cur.pid && s.start === cur.finish) {
            cur = { pid: cur.pid, start: cur.start, finish: s.finish };
        } else {
            out.push(cur);
            cur = { ...s };
        }
    }
    out.push(cur); return out;
}

// ---------------- RMS & EDF (periodic jobs) ----------------
// We'll expand each periodic task into job instances up to the hyperperiod

function scheduleRMS(tasks) {
    // tasks: [{pid, arrival, burst, period}]
    const n = tasks.length;
    const U = tasks.reduce((sum, t) => sum + (t.burst / t.period), 0);
    const U_LL = n * (Math.pow(2, 1 / n) - 1); // Liu & Layland bound

    let schedulable = true;
    let responseTimes = [];

    if (U <= U_LL) {
        console.log(`UT test passed: ${(U * 100).toFixed(2)}% <= ${(U_LL * 100).toFixed(2)}%`);
    } else {
        console.log(`UT test failed: ${(U * 100).toFixed(2)}% > ${(U_LL * 100).toFixed(2)}%`);
    }

    // Response-Time Analysis (RTA)
    // Priority = shorter period = higher priority
    const sortedTasks = tasks.slice().sort((a, b) => a.period - b.period);
    for (let i = 0; i < n; i++) {
        const task = sortedTasks[i];
        let Ri = task.burst;
        let Ri_next;
        do {
            let interference = 0;
            for (let j = 0; j < i; j++) { // higher priority tasks
                interference += Math.ceil(Ri / sortedTasks[j].period) * sortedTasks[j].burst;
            }
            Ri_next = task.burst + interference;
            if (Ri_next === Ri) break;
            if (Ri_next > task.period) {
                schedulable = false;
                break;
            }
            Ri = Ri_next;
        } while (true);
        responseTimes.push({ pid: task.pid, Ri });
        if (Ri > task.period) { schedulable = false; break; }
    }

    // Generate job instances up to hyperperiod
    const H = lcm(...tasks.map(t => t.period));
    const jobs = generateJobs(tasks, H);
    // store generated jobs global for UI mapping
    lastGeneratedJobsGlobal = jobs.map(j => ({ ...j }));

    const segments = schedulePreemptiveByPriority(jobs, (jobA, jobB) => {
        const ta = tasks.find(t => t.pid === jobA.pid);
        const tb = tasks.find(t => t.pid === jobB.pid);
        // shorter period higher priority => smaller number wins
        return (ta.period - tb.period) || (jobA.release - jobB.release);
    }, H);

    // Add feasibility info for UI
    if (schedulable) {
        alert("RMS schedule is FEASIBLE ✅");
    } else {
        alert("RMS schedule is NOT FEASIBLE ❌ (response-time test failed)");
    }

    return { segments: mergeSegments(segments), jobs, feasible: schedulable, responseTimes };
}

function scheduleEDF(tasks) {
    const periods = tasks.map(t => t.period);
    const H = lcm(...periods);
    const jobs = generateJobs(tasks, H);
    lastGeneratedJobsGlobal = jobs.map(j => ({ ...j }));
    // EDF: earlier absolute deadline wins
    const segments = schedulePreemptiveByPriority(jobs, (jobA, jobB) => {
        return (jobA.deadline - jobB.deadline) || (jobA.release - jobB.release);
    }, H);
    return { segments: mergeSegments(segments), jobs };
}

// generate job instances for each task up to hyperperiod H
// each job: { jobId, pid, instance, release, burst, deadline, remaining, finished }
function generateJobs(tasks, H) {
    const jobs = [];
    tasks.forEach(t => {
        // compute how many instances have release < H
        // start k from 0 while release < H
        for (let k = 0;; k++) {
            const release = t.arrival + k * t.period;
            if (release >= H) break;
            const deadline = release + t.period; // implicit deadline
            jobs.push({
                jobId: `${t.pid}_${k + 1}`,
                pid: t.pid,
                instance: k + 1,
                release,
                burst: t.burst,
                deadline,
                remaining: t.burst,
                finished: false,
                startTimes: [],
                finishTime: null
            });
        }
    });
    // sort by release then deadline
    jobs.sort((a, b) => a.release - b.release || a.deadline - b.deadline);
    return jobs;
}

// generic preemptive scheduler that picks at each time unit the highest-priority ready job
// comparator returns negative if a has higher priority than b
function schedulePreemptiveByPriority(jobs, comparator, H) {
    const segments = [];
    const allJobs = jobs.map(j => ({ ...j })); // working copy
    let time = 0;
    while (time < H) {
        // gather ready jobs (released and not finished)
        const ready = allJobs.filter(j => j.release <= time && j.remaining > 0);
        if (ready.length === 0) {
            time++;
            continue;
        }
        // pick best job according to comparator
        ready.sort((a, b) => comparator(a, b));
        const cur = ready[0];
        // execute 1 unit (simulate preemption capability)
        segments.push({ pid: cur.jobId, start: time, finish: time + 1 });
        if (cur.startTimes.length === 0 || cur.startTimes[cur.startTimes.length - 1] !== time) {
            cur.startTimes.push(time);
        }
        cur.remaining -= 1;
        if (cur.remaining === 0) {
            cur.finished = true;
            cur.finishTime = time + 1;
        }
        time++;
    }
    // return per-time-unit segments
    return segments;
}

// ---------------- Table for job instances (RMS/EDF) ----------------
function updateJobTable(jobs) {
    // jobs is the array returned by generateJobs (or lastGeneratedJobsGlobal)
    if (!lastSegmentsGlobal) {
        alert("No schedule to build job table from.");
        return;
    }
    const segs = lastSegmentsGlobal;
    const jobMap = {};
    // initialize jobMap from segs list
    segs.forEach(s => {
        if (!jobMap[s.pid]) jobMap[s.pid] = { start: s.start, finish: s.finish, segments: [{ start: s.start, finish: s.finish }] };
        else {
            jobMap[s.pid].segments.push({ start: s.start, finish: s.finish });
            jobMap[s.pid].start = Math.min(jobMap[s.pid].start, s.start);
            jobMap[s.pid].finish = Math.max(jobMap[s.pid].finish, s.finish);
        }
    });

    // Build table rows
    cpuTable.innerHTML = "";
    // sort job ids by start time for nice presentation
    const sortedJobIds = Object.keys(jobMap).sort((a, b) => {
        const as = jobMap[a].start, bs = jobMap[b].start;
        if (as === undefined) return 1;
        if (bs === undefined) return -1;
        return as - bs;
    });

    sortedJobIds.forEach(jobId => {
        const data = jobMap[jobId];
        // parse jobId => pid_instance
        const parts = jobId.split("_");
        const pid = parts[0];
        const inst = parts[1] || '';
        // find release and deadline from generated jobs if available
        let release = '-', deadline = '-';
        if (lastGeneratedJobsGlobal) {
            const j = lastGeneratedJobsGlobal.find(x => x.jobId === jobId);
            if (j) { release = j.release; deadline = j.deadline; }
        }
        const burst = (data.segments.reduce((acc, s) => acc + (s.finish - s.start), 0)) || '-';
        const start = data.start !== undefined ? data.start : '-';
        const finish = data.finish !== undefined ? data.finish : '-';
        const tat = (finish !== '-' && release !== '-') ? (finish - release) : '-';
        const wt = (tat !== '-' && burst !== '-') ? (tat - burst) : '-';

        const tr = document.createElement("tr");
        tr.innerHTML = `<td>${jobId}</td><td>${release}</td><td>${burst}</td><td>-</td><td>${deadline}</td><td>${start}</td><td>${finish}</td><td>${tat}</td><td>${wt}</td>`;
        cpuTable.appendChild(tr);
    });
}

// ---------------- Gantt drawing ----------------
function drawGantt(segments) {
    // segments: array of {pid, start, finish}
    // store global segments for job table extraction
    lastSegmentsGlobal = segments.slice(); // shallow copy
    // draw
    ganttPanel.innerHTML = "";
    if (!segments.length) return;

    let startTime = Math.min(...segments.map(s => s.start));
    let endTime = Math.max(...segments.map(s => s.finish));
    if (startTime === endTime) endTime = startTime + 1;

    // expand width calculation to account for scrollable panel
    let totalWidth = Math.max(ganttPanel.clientWidth - 40, (endTime - startTime) * 30); // at least 30px per time unit
    let height = ganttPanel.clientHeight - 40;
    const cmap = {};
    segments.forEach(s => {
        if (!cmap[s.pid]) cmap[s.pid] = `hsl(${Math.floor(Math.random() * 360)},60%,45%)`;
    });

    segments.forEach(s => {
        let x = 20 + ((s.start - startTime) / (endTime - startTime)) * totalWidth;
        let w = ((s.finish - s.start) / (endTime - startTime)) * totalWidth;
        if (!isFinite(x) || !isFinite(w)) { x = 20 + (s.start - startTime) * 30; w = (s.finish - s.start) * 30; }
        const bar = document.createElement("div");
        bar.className = "ganttBar";
        bar.style.position = "absolute";
        bar.style.left = x + "px";
        bar.style.top = "10px";
        bar.style.width = Math.max(2, w) + "px";
        bar.style.background = cmap[s.pid];
        bar.style.height = "28px";
        // only show label if bar is wide enough
        if (w > 25) bar.innerText = s.pid;
        ganttPanel.appendChild(bar);
    });

    // time labels
    for (let t = startTime; t <= endTime; t++) {
        let x = 20 + ((t - startTime) / (endTime - startTime)) * totalWidth;
        if (!isFinite(x)) x = 20 + (t - startTime) * 30;
        const lbl = document.createElement("div");
        lbl.className = "timeLabel";
        lbl.style.position = "absolute";
        lbl.style.left = (x - 6) + "px";
        lbl.style.top = (60) + "px";
        lbl.innerText = t;
        ganttPanel.appendChild(lbl);
    }

    // make panel horizontally scrollable if needed
    ganttPanel.style.minWidth = Math.max(totalWidth + 60, ganttPanel.clientWidth) + "px";
    ganttPanel.style.position = "relative";
}

// ---------------- CPutable for non-periodic algorithms (per-process summary) ----------------
function updateCPUTable(segments) {
    cpuTable.innerHTML = "";
    const map = {};
    segments.forEach(s => (map[s.pid] = map[s.pid] || []).push(s));
    processes.forEach(p => {
        let segs = map[p.pid] || [];
        if (!segs.length) {
            cpuTable.innerHTML += `<tr><td>${p.pid}</td><td>${p.arrival}</td><td>${p.burst}</td><td>${p.period || '-'}</td><td>-</td><td>-</td><td>-</td><td>-</td><td>${p.priority || '-'}</td></tr>`;
        } else {
            // ensure segs sorted
            segs.sort((a, b) => a.start - b.start);
            let start = segs[0].start, finish = segs[segs.length - 1].finish;
            let tat = finish - p.arrival, wt = tat - p.burst;
            cpuTable.innerHTML += `<tr><td>${p.pid}</td><td>${p.arrival}</td><td>${p.burst}</td><td>${p.period || '-'}</td><td>-</td><td>${start}</td><td>${finish}</td><td>${tat}</td><td>${wt}</td></tr>`;
        }
    });
}

// ---------------- Utility functions: gcd & lcm ----------------
function gcd(a, b) {
    a = Math.abs(a); b = Math.abs(b);
    if (a === 0) return b;
    if (b === 0) return a;
    while (b) {
        const t = a % b; a = b; b = t;
    }
    return a;
}
function lcm(...nums) {
    if (!nums.length) return 1;
    // filter zeros out (period of zero is invalid), but guard anyway
    nums = nums.map(n => Math.abs(Math.floor(n) || 0)).filter(n => n > 0);
    if (!nums.length) return 1;
    return nums.reduce((a, b) => (a * b) / gcd(a, b));
}

// ---------------- Banker's Algorithm functions (unchanged from your original) ----------------
function buildBankerTables() {
    const P = parseInt(document.getElementById("numProcesses").value);
    const R = parseInt(document.getElementById("numResources").value);

    let html = "<h3>Allocation Matrix</h3><table border='1'>";
    for (let i = 0; i < P; i++) {
        html += "<tr>";
        for (let j = 0; j < R; j++) {
            html += `<td><input type='number' id='alloc_${i}_${j}' value='0' style='width:50px'></td>`;
        }
        html += "</tr>";
    }
    html += "</table>";

    html += "<h3>Max Matrix</h3><table border='1'>";
    for (let i = 0; i < P; i++) {
        html += "<tr>";
        for (let j = 0; j < R; j++) {
            html += `<td><input type='number' id='max_${i}_${j}' value='0' style='width:50px'></td>`;
        }
        html += "</tr>";
    }
    html += "</table>";

    html += "<h3>Available Resources</h3>";
    for (let j = 0; j < R; j++) {
        html += `R${j}: <input type='number' id='avail_${j}' value='0' style='width:50px'> `;
    }
    html += `<br><br><button onclick="runBanker()">Run Banker's Algorithm</button>`;
    document.getElementById("bankerTables").innerHTML = html;
}

function readBankerData() {
    const P = parseInt(document.getElementById("numProcesses").value);
    const R = parseInt(document.getElementById("numResources").value);
    const alloc = Array.from({ length: P }, (_, i) => Array.from({ length: R }, (_, j) => parseInt(document.getElementById(`alloc_${i}_${j}`).value) || 0));
    const max = Array.from({ length: P }, (_, i) => Array.from({ length: R }, (_, j) => parseInt(document.getElementById(`max_${i}_${j}`).value) || 0));
    const avail = Array.from({ length: R }, (_, j) => parseInt(document.getElementById(`avail_${j}`).value) || 0);
    return { alloc, max, avail };
}

function computeNeed(max, alloc) {
    return max.map((row, i) => row.map((val, j) => Math.max(0, val - alloc[i][j])));
}

function bankersSafety(alloc, max, avail) {
    const P = alloc.length, R = avail.length;
    const need = computeNeed(max, alloc);
    const work = [...avail];
    const finish = Array(P).fill(false);
    const seq = [];
    let progressed;
    do {
        progressed = false;
        for (let i = 0; i < P; i++) {
            if (finish[i]) continue;
            let can = true;
            for (let j = 0; j < R; j++) if (need[i][j] > work[j]) { can = false; break; }
            if (can) {
                for (let j = 0; j < R; j++) work[j] += alloc[i][j];
                finish[i] = true;
                seq.push(`P${i}`);
                progressed = true;
            }
        }
    } while (progressed);
    return { isSafe: finish.every(f => f), sequence: seq };
}

function runBanker() {
    const { alloc, max, avail } = readBankerData();
    const result = bankersSafety(alloc, max, avail);
    const resDiv = document.getElementById("bankerResult");
    if (result.isSafe) resDiv.innerHTML = "System is SAFE.<br>Safe Sequence:  " + result.sequence.join(" → ");
    else resDiv.innerHTML = "System is NOT SAFE. No safe sequence found.";
}
